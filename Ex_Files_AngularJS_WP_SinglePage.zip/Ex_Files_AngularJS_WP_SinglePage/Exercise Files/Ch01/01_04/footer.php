		</div><!-- END CONTAINER -->  
		</div><!-- END FLUID CONTAINER -->	
		
		<footer class="container-fluid">
			<div class="container">
				<div class="row">
					<div class="col-sm-12 text-center">
						<p>
							&copy; <?php echo Date('Y'); ?>
						</p>
					</div>
				</div>
			</div>
		</footer>  
    <!-- WP FOOTER -->
  	<?php wp_footer(); ?>
	    
</body>
</html>
