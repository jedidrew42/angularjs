<?php get_header(); ?>
	<div ui-view></div>
<?php get_footer(); ?>